define(function () {
    return[
        {"type":"collection",
            "current_page":1,
            "per_page":30,
            "total_entries":3,
            "total_pages":1,
            "items":[
                {"json_class":"Channel","activated":true,"carrier":null,"ctype":"email","id":1,"name":"tibbradmin_channel","paused":true,"rich_text":false,"target":"tibbr-support@tibco.com","user_id":1,"actions":"edit,delete,activate,play"},
                {"json_class":"Channel","activated":false,"carrier":null,"ctype":"email","id":15,"name":"gunita.bindra8@tibco.com","paused":false,"rich_text":false,"target":"gunita.bindra8@tibco.com","user_id":1,"actions":"edit,delete,activate,pause"},
                {"json_class":"Channel","activated":true,"carrier":null,"ctype":"email","id":80,"name":"gunita.bindra009@tibco.com","paused":false,"rich_text":false,"target":"gunita.bindra009@tibco.com","user_id":1,"actions":"edit,delete,activate,pause"}
            ]}
]})