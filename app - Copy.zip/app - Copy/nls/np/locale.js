define({
    "first_name":"नाम",
    "last_name":"थर",
        "user":{
            "name":"नाम",
            "first_name":"First Name",
            "last_name":"Last Name",
            "email":"Email",
            "phone":"Phone",
            "company":"Company",
            "department":"Department",
            "location":"Location",
            "mobile":"Mobile",
            "office":"Office",
            "about_me":"About Me",
            "edit_my_profile":"Edit My Profile",
            "followers":"नाम: <span>%d</span>",
            "following":"नाम: <span>%d</span>"
        }
    }
);